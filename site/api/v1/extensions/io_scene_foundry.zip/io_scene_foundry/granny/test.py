from .functions import *
from .formats import *
from . import Granny, new_callback_function

GrannyCallbackType = CFUNCTYPE(
    None,
    c_int,
    c_int,
    c_char_p,
    c_int,
    c_char_p,
    c_void_p
)

def new_granny(filename: str):
    granny = Granny("F:\Modding\Main\HREK\granny2_x64.dll")
    print(granny.get_version_string())
    new_callback = granny.old_callback
    new_callback.function = GrannyCallbackType(new_callback_function)
    new_callback.user_data = None
    granny.set_log_callback(new_callback)
    
    file_info = GrannyFileInfo()
    file_info.art_tool_info = GrannyFileArtToolInfo()
    file_info.exporter_info = GrannyFileExporterInfo()
    file_info.file_name = filename.encode('utf-8')
    file_info.texture_count = 0
    file_info.textures = None
    file_info.material_count = 0
    file_info.materials = None
    file_info.skeleton_count = 0
    file_info.skeletons = None
    file_info.vertex_data_count = 0
    file_info.vertex_datas = None
    file_info.tri_topology_count = 0
    file_info.tri_topologies = None
    file_info.mesh_count = 0
    file_info.meshes = None
    file_info.model_count = 0
    file_info.models = None
    file_info.track_group_count = 0
    file_info.track_groups = None
    file_info.animation_count = 0
    file_info.animations = None
    file_info.extended_data.type = None
    file_info.extended_data.object = None

    # file_info.art_tool_info = GrannyFileArtToolInfo()
    # file_info.exporter_info = GrannyFileExporterInfo()
    
    file_section_count = c_int32(1)
    default_section_index = c_int32(0)
    data_tree_writer = granny_begin_file_data_tree_writing(granny.file_info_type, file_info, default_section_index, default_section_index)
    granny_write_data_tree_to_file(data_tree_writer, 0, granny.magic_value, filename, file_section_count)
    print(granny_write_data_tree_to_file)
    # if data_tree_writer:
    #     result = granny_write_data_tree_to_file(data_tree_writer, 0, granny_mv(), filename, file_section_count)
    # else:
    #     print("not data_tree_writer")
        
    granny_end_file_data_tree_writing(data_tree_writer)
    