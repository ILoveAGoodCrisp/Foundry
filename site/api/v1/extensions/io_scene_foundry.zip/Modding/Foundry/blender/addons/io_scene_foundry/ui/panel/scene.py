"""UI for the scene properties sub-panel"""
