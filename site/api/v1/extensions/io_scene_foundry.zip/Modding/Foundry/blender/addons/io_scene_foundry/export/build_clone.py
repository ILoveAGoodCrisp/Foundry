import os
from pathlib import Path
import bpy
import xml.etree.cElementTree as ET
import xml.dom.minidom

from .. import utils

        

class Clone:
    def __init__(self, sidecar_path_full: Path, sidecar_path: Path, asset_path: Path, asset_name: str, asset_type: AssetType, scene_settings: NWO_ScenePropertiesGroup, corinth: bool, context: bpy.types.Context):
        self.reach_world_animations = set()
        self.pose_overlays = set()
        self.relative_asset_path = relative_path(asset_path)
        self.tag_path = relative_path(Path(asset_path, asset_name))
        self.asset_path = asset_path
        self.asset_name = asset_name
        self.asset_type = asset_type
        self.sidecar_path = sidecar_path
        self.sidecar_path_full = sidecar_path_full
        self.relative_blend = bpy.data.filepath
        self.relative_blend = str(Path(bpy.data.filepath).relative_to(get_data_path())) if Path(bpy.data.filepath).is_relative_to(get_data_path()) else bpy.data.filepath
        self.external_blend = self.relative_blend == bpy.data.filepath
        self.scene_settings = scene_settings
        self.corinth = corinth
        self.context = context
        self.lods = set()
        
        self.structure = set()
        self.design = set()
        self.has_armature = False
        self.regions = []
        self.global_materials = []
        self.file_data: dict[list[SidecarFileData]] = defaultdict(list)
        self.child_sidecar_paths = []
        self.child_animation_elements = []
        self.child_physics_elements = []
        self.child_collision_elements = []
        self.child_render_elements = []
        self.child_bsp_elements = []
        
    def build(self):
        m_encoding = "utf-8"
        m_standalone = "yes"
        clones = ET.Element("Clones")
        for source_dest in self.permutations:
            source, dest  = source_dest
            clone = ET.SubElement(clones, "Clone", source=source, destination=dest)
            for mat_override in material_overrides:
                material_override = ET.SubElement(clone, "MaterialOverride")
                ET.SubElement(material_override, "Original").text=mat_override.original
                ET.SubElement(material_override, "Override").text=mat_override.override

        dom = xml.dom.minidom.parseString(ET.tostring(clones))
        xml_string = dom.toprettyxml(indent="  ")
        part1, part2 = xml_string.split("?>")

        if Path(self.sidecar_path_full).exists():
            if not os.access(self.sidecar_path_full, os.W_OK):
                raise RuntimeError(f"Sidecar is read only, cannot complete export: {self.sidecar_path_full}\n")
        
        with open(self.sidecar_path_full, "w") as f:
            f.write(part1 + 'encoding="{}" standalone="{}"?>'.format(m_encoding, m_standalone))
            for line in part2.splitlines():
                if line.strip():
                    f.write(line + "\n")