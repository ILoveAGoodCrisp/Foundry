from . import Tag
    
class CinematicSceneDataTag(Tag):
    tag_ext = 'cinematic_scene_data'