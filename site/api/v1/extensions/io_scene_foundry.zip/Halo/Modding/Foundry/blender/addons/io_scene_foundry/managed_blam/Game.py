

class GameColor: pass
class GamePoint2d: pass